export const faqs = [
  {
    id: 1,
    question: 'What is FSU?',
    answer:
      'Eu irure sit laboris est ipsum mollit sint mollit culpa nostrud mollit. Dolor aute ea minim anim quis. Dolor est anim dolor elit cupidatat eu.',
  },
  {
    id: 2,
    question: 'What is the agenda of FSU?',
    answer:
      'Cupidatat consequat et anim sit veniam nostrud pariatur voluptate pariatur officia qui. Magna aliquip duis ex dolore tempor ad nisi nisi laboris. Consectetur pariatur aliquip esse sit quis nostrud enim aute ex. Consectetur veniam veniam fugiat ut anim magna consequat quis commodo. Laborum cillum ut consequat nulla. Nostrud consectetur dolore id elit laborum consectetur ad magna nisi cillum veniam sint.',
  },
  {
    id: 3,
    question: 'How FSU is changing the environment of Purwanchal Campus?',
    answer:
      'Proident sunt amet labore laborum eu duis cupidatat Lorem qui incididunt ut ipsum laborum ea. Veniam cupidatat eiusmod incididunt cillum duis anim. Anim ut mollit laborum ullamco esse ut. Exercitation consectetur nulla nostrud non consequat voluptate ullamco. Excepteur magna id minim consectetur nostrud qui reprehenderit incididunt consequat officia reprehenderit ad aliquip. Cillum irure in ea ut. Ut ad duis nostrud laboris eu elit ut ipsum.',
  },
  {
    id: 3,
    question: 'How FSU is changing the environment of Purwanchal Campus?',
    answer:
      'Proident sunt amet labore laborum eu duis cupidatat Lorem qui incididunt ut ipsum laborum ea. Veniam cupidatat eiusmod incididunt cillum duis anim. Anim ut mollit laborum ullamco esse ut. Exercitation consectetur nulla nostrud non consequat voluptate ullamco. Excepteur magna id minim consectetur nostrud qui reprehenderit incididunt consequat officia reprehenderit ad aliquip. Cillum irure in ea ut. Ut ad duis nostrud laboris eu elit ut ipsum.',
  },
  // Add more questions and answers as needed
];
