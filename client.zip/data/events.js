export const upcomingEvents = [
  { id: 1, image: '/images/events/fsu cup.jpg', name: 'FSU Cup' },
  { id: 2, image: '/images/events/cricket.jpg', name: 'Cricket' },
  { id: 3, image: '/images/events/football.jpg', name: 'Football' },
  { id: 4, image: '/images/events/AI ML.jpg', name: 'AI ML' },
  { id: 5, image: '/images/events/erc-run.jpg', name: 'ERC Run' },
  { id: 5, image: '/images/events/erc-run.jpg', name: 'ERC Run' },
];

export const pastEvents = [
  { id: 1, image: '/images/events/fsu cup.jpg', name: 'FSU Cup' },
  { id: 2, image: '/images/events/cricket.jpg', name: 'Cricket' },
  { id: 3, image: '/images/events/football.jpg', name: 'Football' },
  { id: 4, image: '/images/events/AI ML.jpg', name: 'AI ML' },
  { id: 5, image: '/images/events/erc-run.jpg', name: 'ERC Run' },
  { id: 6, image: '/images/events/erc-run.jpg', name: 'ERC Run' },
  { id: 7, image: '/images/events/erc-run.jpg', name: 'ERC Run' },
  { id: 8, image: '/images/events/erc-run.jpg', name: 'ERC Run' },
];
