export const testimonials = [
  {
    id: 1,
    name: 'Nabin Shrestha',
    quotes:
      'Ad quis enim ullamco culpa dolor et nulla eiusmod est. Consequat aute excepteur voluptate occaecat dolor ea adipisicing nostrud. Cillum ad ex aliquip dolor nostrud deserunt in sit consequat sit consequat cillum ea non. Aute reprehenderit id do incididunt ut tempor consequat culpa. Id adipisicing ipsum voluptate esse dolore excepteur occaecat excepteur exercitation consectetur nulla.',
    image: '/images/committee/nabin_stha.png',
    position: 'FSU President',
    facebook: '',
    twitter: '',
  },
  {
    id: 2,
    name: 'Nabin Shrestha',
    quotes:
      'Ad quis enim ullamco culpa dolor et nulla eiusmod est. Consequat aute excepteur voluptate occaecat dolor ea adipisicing nostrud. Cillum ad ex aliquip dolor nostrud deserunt in sit consequat sit consequat cillum ea non. Aute reprehenderit id do incididunt ut tempor consequat culpa. Id adipisicing ipsum voluptate esse dolore excepteur occaecat excepteur exercitation consectetur nulla.',
    image: '/images/committee/nabin_stha.png',
    position: 'FSU President',
    facebook: '',
    twitter: '',
  },
  {
    id: 3,
    name: 'Nabin Shrestha',
    quotes:
      'Ad quis enim ullamco culpa dolor et nulla eiusmod est. Consequat aute excepteur voluptate occaecat dolor ea adipisicing nostrud. Cillum ad ex aliquip dolor nostrud deserunt in sit consequat sit consequat cillum ea non. Aute reprehenderit id do incididunt ut tempor consequat culpa. Id adipisicing ipsum voluptate esse dolore excepteur occaecat excepteur exercitation consectetur nulla.',
    image: '/images/committee/nabin_stha.png',
    position: 'FSU President',
    facebook: '',
    twitter: '',
  },
  {
    id: 4,
    name: 'Nabin Shrestha',
    quotes:
      'Ad quis enim ullamco culpa dolor et nulla eiusmod est. Consequat aute excepteur voluptate occaecat dolor ea adipisicing nostrud. Cillum ad ex aliquip dolor nostrud deserunt in sit consequat sit consequat cillum ea non. Aute reprehenderit id do incididunt ut tempor consequat culpa. Id adipisicing ipsum voluptate esse dolore excepteur occaecat excepteur exercitation consectetur nulla.',
    image: '/images/committee/nabin_stha.png',
    position: 'FSU President',
    facebook: '',
    twitter: '',
  },
];
