export const messages = [
  {
    id: 1,
    content:
      'Consequat aliquip pariatur magna id. Labore ea consequat dolor labore esse veniam cupidatat sunt nulla tempor aliquip cupidatat. Deserunt enim culpa anim mollit nisi amet irure excepteur nostrud. Eiusmod cupidatat aute eu occaecat sunt sunt labore cillum nulla veniam eu. Aliquip in laboris ipsum Lorem eiusmod. Ea ut Lorem adipisicing do sint.Anim proident adipisicing cupidatat veniam. Ipsum anim excepteur incididunt cillum dolor adipisicing exercitation tempor ullamco proident ex qui. Consequat cillum reprehenderit do consequat est et sit ea sit velit ad ad. Eu sit fugiat amet consequat. Incididunt laborum consequat velit culpa tempor occaecat occaecat eu officia. Adipisicing esse consequat aute labore aliquip fugiat.',
    image: '/images/committee/nabin_stha.png',
    name: 'Nabin Shrestha',
    position: 'President of FSU',
    faculty: 'Agricultural Engineering',
  },
  {
    id: 2,
    content:
      'Culpa duis non in ut anim est proident occaecat do ipsum eiusmod adipisicing. Consectetur laboris cupidatat duis labore officia aliquip sint quis. Commodo duis aliquip dolore ad anim magna incididunt aliquip ullamco incididunt reprehenderit. Exercitation est voluptate quis commodo.Minim voluptate exercitation ullamco velit. Esse occaecat ullamco esse occaecat ullamco sit cillum Lorem aute esse. Lorem laboris culpa id ut reprehenderit tempor aliqua. Laborum reprehenderit non dolore enim laborum amet mollit consectetur laborum in ullamco. Lorem aliquip nostrud veniam non incididunt ullamco exercitation est anim.',
    image: '/images/committee/rajan yadav.png',
    name: 'Rajan yadav',
    position: 'Secretary of FSU',
    faculty: 'Electronics and Computer Engineering',
  },
];

export const notices = [
  {
    id: 1,
    title: 'Student not permitted to enter in the campus area after 5:15 PM',
    content: '',
  },
  {
    id: 1,
    title: 'Student not permitted to enter in the campus area after 5:15 PM',
    content: '',
  },
  {
    id: 1,
    title: 'Student not permitted to enter in the campus area after 5:15 PM',
    content: '',
  },
  {
    id: 1,
    title: 'Student not permitted to enter in the campus area after 5:15 PM',
    content: '',
  },
  {
    id: 1,
    title: 'Student not permitted to enter in the campus area after 5:15 PM',
    content: '',
  },
];

export const coreValues = [
  {
    id: 1,
    title: 'Advocacy',
    desc: 'Minim tempor cillum in pariatur deserunt ut excepteur non sint duis ex. Deserunt ut occaecat minim consectetur proident commodo amet dolor mollit aliquip. Laboris et deserunt ea mollit commodo enim nulla qui occaecat exercitation quis elit consectetur.',
  },
  {
    id: 2,
    title: 'Inclusivity',
    desc: 'Minim tempor cillum in pariatur deserunt ut excepteur non sint duis ex. Deserunt ut occaecat minim consectetur proident commodo amet dolor mollit aliquip. Laboris et deserunt ea mollit commodo enim nulla qui occaecat exercitation quis elit consectetur.',
  },
  {
    id: 3,
    title: 'Transparency',
    desc: 'Minim tempor cillum in pariatur deserunt ut excepteur non sint duis ex. Deserunt ut occaecat minim consectetur proident commodo amet dolor mollit aliquip. Laboris et deserunt ea mollit commodo enim nulla qui occaecat exercitation quis elit consectetur.',
  },
  {
    id: 4,
    title: 'Collaboration',
    desc: 'Minim tempor cillum in pariatur deserunt ut excepteur non sint duis ex. Deserunt ut occaecat minim consectetur proident commodo amet dolor mollit aliquip. Laboris et deserunt ea mollit commodo enim nulla qui occaecat exercitation quis elit consectetur.',
  },
  // {
  //   id: 5,
  //   title: 'Transparency',
  //   desc: 'Minim tempor cillum in pariatur deserunt ut excepteur non sint duis ex. Deserunt ut occaecat minim consectetur proident commodo amet dolor mollit aliquip. Laboris et deserunt ea mollit commodo enim nulla qui occaecat exercitation quis elit consectetur.',
  // },
  // {
  //   id: 6,
  //   title: 'Transparency',
  //   desc: 'Minim tempor cillum in pariatur deserunt ut excepteur non sint duis ex. Deserunt ut occaecat minim consectetur proident commodo amet dolor mollit aliquip. Laboris et deserunt ea mollit commodo enim nulla qui occaecat exercitation quis elit consectetur.',
  // },
];
