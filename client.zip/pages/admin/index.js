import React from 'react';

const Admin = () => {
  return <div>Admin</div>;
};

export default Admin;

// export const getServerSideProps = async (context) => {
//   console.log(context.req.cookies);
//   return {
//     props: {},
//   };
// };
